#include "work.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "main.h"
/**************************************************************************
 * 麦克风摆放方式：
 *                    Mic3
 *                      @
 *
 *
 *                    Mic1
 *                      @
 *
 *
 *                      @
 *                    Mic2
 *
 *
 *************************************************************************/
#ifndef PI
# define PI 3.14159265358979323846264338327950288
#endif

#define gccNUM 151

int xcorr(float* x1,float* x2)
{
	int i,j;
	float max;
	float cc[2*gccNUM-1];                        //n=151,只运算中间151个点的值，减小运算
	for(i=0;i<2*gccNUM-1;i++)
	{
			cc[i]=0.0;
	}
	// m>=0
	for(i=0;i<gccNUM;i++)
	{
			for(j=0;j<512-i;j++)
			{
					cc[gccNUM+i-1] += x1[j+i]*x2[j];        
			}
	}
	// m<0
	for(i=1;i<gccNUM;i++)
	{
			for(j=0;j<512-i;j++)
			{
					cc[gccNUM-i-1] += x1[j]*x2[j+i];        
			}
	}
	//get max[cc]
	max = cc[0];
	for(i=1;i<2*gccNUM-1;i++)
	{
			if(max<cc[i])
			{
					max = cc[i];
					j = i;
			}
	}
	printf("\n%f\n",max);
	j = j - gccNUM+1;        //j-n-1
	return (j);                //get delay *us
}





























typedef struct
{
    float real;
    float imag;
}complex;//定义负数
//两个复数相乘
complex mul(complex a, complex b)
{
	complex c;
    c.real = a.real*b.real - a.imag*b.imag;
    c.imag = a.real*b.imag + a.imag*b.real;
    return c;
}
//复数求出幅值
double Absolute_Value(complex a)
{
   	double rea,ima;
   	double value;
   	rea=a.real*a.real;
   	ima=a.imag*a.imag;
//	printf("genhao");
   	value=sqrt(rea+ima);
//	printf("genwan");
   	return value;
}
/*为了更好说明分治思想，这里采用递归实现，结束条件为N<=1*/
void FFT( complex *output, complex *input, int n )
{
  if(n>1) {   /* N如小于1，直接返回*/
    int k,m;    
	complex z, w, *vo, *ve;
    ve = output; vo = output+n/2;
    for(k=0; k<n/2; k++) {
      ve[k] = input[2*k];
      vo[k] = input[2*k+1];
    }
    FFT( ve, input, n/2 );  /* FFT 偶数序列 input[] */
    FFT( vo, input, n/2  );  /* FFT 偶数序列 input[] */
    for(m=0; m<n/2; m++) {
      w.real = cos(2*PI*m/(double)n);
      w.imag = -sin(2*PI*m/(double)n);
      z.real = w.real*vo[m].real - w.imag*vo[m].imag; /* Real(w*vo[m]) */
      z.imag = w.real*vo[m].imag + w.imag*vo[m].real; /* Imag(w*vo[m]) */
      input[  m  ].real = ve[m].real + z.real;
      input[  m  ].imag = ve[m].imag + z.imag;
      input[m+n/2].real = ve[m].real - z.real;
      input[m+n/2].imag = ve[m].imag - z.imag;
    }
  }
  return;
}

/*为了更好说明分治思想，这里采用递归实现，结束条件为N<=1*/
void IFFT( complex *output, complex *input, int n )
{
  if(n>1) {   
    int k,m;    
	complex z, w, *vo, *ve;
    ve = output; vo = output+n/2;
    for(k=0; k<n/2; k++) {
      ve[k] = input[2*k];
      vo[k] = input[2*k+1];
    }
    IFFT( ve, input, n/2 );  /* FFT 偶数序列 input[] */
    IFFT( vo, input, n/2 );  /* FFT 奇数序列 input[] */
    for(m=0; m<n/2; m++) {
      w.real = cos(2*PI*m/(double)n);
      w.imag = sin(2*PI*m/(double)n);
      z.real = w.real*vo[m].real - w.imag*vo[m].imag; /* Real(w*vo[m]) */
      z.imag = w.real*vo[m].imag + w.imag*vo[m].real; /* Imag(w*vo[m]) */
      input[  m  ].real = ve[m].real + z.real;
      input[  m  ].imag = ve[m].imag + z.imag;
      input[m+n/2].real = ve[m].real - z.real;
      input[m+n/2].imag = ve[m].imag - z.imag;
    }
  }
  return;
}

/*********************************************************
 ********************* 核心函数 **************************
 * 函数功能：1.Mic1和Mic2采集麦克风数据
 *           2.通过互相关算法求出时延
 ********************************************************/
complex Mic1_fftIn[FFT_Pointer];
complex Mic2_fftIn[FFT_Pointer];
complex Mic1_fftOut[FFT_Pointer];
complex Mic2_fftOut[FFT_Pointer];
complex Mic_ifftOut[FFT_Pointer];              //互相关运算的结果
complex Mic1_ifftMul[FFT_Pointer];
double Mic_max=0;
double MIC_ifftOut[FFT_Pointer]; 
int Max_Array_Num=0;      //最大值对应的数组下标  

float find_shijiacha(uint16_t a[],uint16_t b[],int num)
{
	int i;
	//int array[3];
	           //互相关运算的结果的模
//	for(i=0;i<num*2;i++)
//	{
//		MIC_ifftOut[i]=0;
//	}
	for(i=0;i<num;i++)
	{
		Mic1_fftIn[i].real      =a[i]*3.3/4096;  //ADC_ReadAverage(ADC1,3);
		Mic2_fftIn[num-i-1].real=b[i]*3.3/4096;  //ADC_ReadAverage(ADC2,3);
		Mic1_fftIn[i+num].real  =0;    //补零，参与FFT的数组长度为2倍采样速率
		Mic1_fftIn[i].imag      =0;
		Mic1_fftIn[i+num].imag  =0;    //补零，参与FFT的数组长度为2倍采样速率
		Mic2_fftIn[i+num].real  =0;    //补零，参与FFT的数组长度为2倍采样速率
		Mic2_fftIn[num-i-1].imag=0;
		Mic2_fftIn[i+num].imag  =0;    //补零，参与FFT的数组长度为2倍采样速率
	}
	printf("begin fft\r\n");
	FFT(Mic1_fftOut, Mic1_fftIn, num*2);     //Mic1的傅里叶变换
	FFT(Mic2_fftOut, Mic2_fftIn, num*2);     //Mic2的傅里叶变换
	printf("end fft\r\n");
	for(i=0;i<num*2;i++)
	{
		Mic2_fftOut[i].imag=-Mic2_fftOut[i].imag; 		//fft2取共轭
	}
	for(i=0;i<num*2;i++)
	{
		Mic1_ifftMul[i]=mul(Mic1_fftOut[i],Mic2_fftOut[i]);      //两个信号频域的乘积
	}
	IFFT(Mic_ifftOut, Mic1_ifftMul, num*2);  //FFT的逆变换
	printf("hhh\r\n");
	for(i=0;i<num*2;i++)
	{
		printf("%d\r\n",i);
		//if(i==672)continue;
		//if(i==679)continue;
		MIC_ifftOut[i]=Absolute_Value(Mic_ifftOut[i]);           //取模值
		//MIC_ifftOut[i]=sqrt(Mic_ifftOut[i].real*Mic_ifftOut[i].real+Mic_ifftOut[i].imag*Mic_ifftOut[i].imag);
	}
	printf("MIC\r\n");
	for(i=0;i<num*2;i++)
	{
	//	printf("%.4f\r\n",MIC_ifftOut[i]);
	//	printf("+++");
		if(MIC_ifftOut[i]>Mic_max)
		{
			Mic_max=MIC_ifftOut[i];            //找出幅值最大的点
			Max_Array_Num=i;                   //最大值对应的数组下标
		}
	}
	printf("%d",Max_Array_Num);
	return Max_Array_Num-num+1;  //得到时延的下标差
}
/***********************************************************
 * 函数功能：滤除ADC采集的chirp数据中的间隔成分
 * 函数参数：Filter_Num：前后滤波的长度
 * 函数返回值：
 * 函数说明：两个数组的两边各取Filter_Num个数据
 *           判断采样的数据是否位于间隔区域
 **********************************************************/
//uchar ADC_Data_Filter(uint Filter_Num)
//{
//    uint i;
//    uchar Mic1_Start_flag=0;
//    uchar Mic1_End_flag=0;
//    uchar Mic2_Start_flag=0;
//    uchar Mic2_End_flag=0;
//    for(i=0;i<Filter_Num;)
//	{
//		Mic1_fftIn[i].real               =ADC_Read(ADC1);
//		Mic2_fftIn[Sampling_Num-i-1].real=ADC_Read(ADC2);

//		if(1600<Mic1_fftIn[i].real&&Mic1_fftIn[i].real<1800)
//		{
//			i++;
//			if(i==Filter_Num)
//			{
//				Mic1_Start_flag=1;
//			}
//		}
//	}
//    for(i=0;i<Filter_Num;)
//	{
//		if(1600<Mic1_fftIn[Sampling_Num-i-1].real&&Mic1_fftIn[Sampling_Num-i-1].real<1800)
//		{
//			i++;
//			if(i==Filter_Num)
//			{
//				Mic1_End_flag=1;
//			}
//		}
//	}
//    for(i=0;i<Filter_Num;)
//	{
//		if(1600<Mic2_fftIn[Sampling_Num-i-1].real&&Mic2_fftIn[Sampling_Num-i-1].real<1800)
//		{
//			i++;
//			if(i==Filter_Num)
//			{
//				Mic2_Start_flag=1;
//			}
//		}
//	}
//    for(i=0;i<Filter_Num;)
//	{
//		if(1600<Mic2_fftIn[i].real&&Mic2_fftIn[i].real<1800)
//		{
//			i++;
//			if(i==Filter_Num)
//			{
//				Mic2_End_flag=1;
//			}
//		}
//	}
//    if((Mic1_Start_flag==1&&Mic1_End_flag==1)||(Mic2_Start_flag==1&&Mic2_End_flag==1))
//        return 0;
//    else
//    	return 1;
//}

//int Mic_PID(float Mic_Deviation_Want)
//{
//	int Deviation;
//	Mic_Deviation[2]=Mic_Deviation[1];
//	Mic_Deviation[1]=Mic_Deviation[0];
//	Mic_Deviation[0]=Mic_Deviation_Want-Mic12_Deviation;
//	P_Mic_Deviation = Mic_Kp*(Mic_Deviation[0]-Mic_Deviation[1]);
//	I_Mic_Deviation = Mic_Ki*Mic_Deviation[0];
//	D_Mic_Deviation = Mic_Kd*(Mic_Deviation[0]-2*Mic_Deviation[1]+Mic_Deviation[2]);
//	Finally_Deviation+=P_Mic_Deviation+I_Mic_Deviation+D_Mic_Deviation;
//    if(Finally_Deviation<-2*Refer_Speed/5)
//    	Finally_Deviation=-2*Refer_Speed/5;
//    if(Finally_Deviation>2*Refer_Speed/5)
//    	Finally_Deviation=2*Refer_Speed/5;
//    Deviation = (int)Finally_Deviation;
//    return Deviation;
//}

/****************************************************************************************
 * 函数功能：用于方向PID计算后矫正转速控制
 * 函数参数：
 *           Main_Speed：麦轮的基本转动速度
 *            Deviation：由方向PID计算出的左右两边麦轮速度的差值
 *                 mode: 两边麦轮有转速差(1);还是后两个速度不变，前两个有转速差(0)
 * 函数说明：当信标与左麦克风Mic_x1 > 右麦克风的距离Mic_x2时，
 *                   左边麦轮speed1 > 右边麦轮速度speed2,
 *    Mic12_Deviation=Mic_x1-Mic_x2 > 0.
 *              车模向右运动;
 *           当信标与左麦克风Mic_x1 < 右麦克风的距离Mic_x2时，
 *                   左边麦轮speed1 < 右边麦轮速度speed2,
 *    Mic34_Deviation=Mic_x1-Mic_x2 < 0.
 *              车模向左运动.
// ***************************************************************************************/
//void Direction_Correction(uint Main_Speed,int Deviation,Mode mode)
//{
//	if(Mic34_Deviation <= 0)  //声标在车模上方
//	{
//		if(mode)
//		{
//			 Single_Wheel_Control(A1,Front,Main_Speed+Deviation);
//			 Single_Wheel_Control(B2,Front,Main_Speed+Deviation);
//			 Single_Wheel_Control(B1,Front,Main_Speed-Deviation);
//			 Single_Wheel_Control(A2,Front,Main_Speed-Deviation);
//		}
//		else
//		{
//			 Single_Wheel_Control(A1,Front,Main_Speed+Deviation);
//			 Single_Wheel_Control(B1,Front,Main_Speed-Deviation);
//			 Single_Wheel_Control(B2,Front,Main_Speed);
//			 Single_Wheel_Control(A2,Front,Main_Speed);
//		}
//	}
//	if(Mic34_Deviation > 0)   //声标在车模下方
//	{
//		if(mode)
//		{
//			 Single_Wheel_Control(A1,Back,Main_Speed+Deviation);
//			 Single_Wheel_Control(B2,Back,Main_Speed+Deviation);
//			 Single_Wheel_Control(B1,Back,Main_Speed-Deviation);
//			 Single_Wheel_Control(A2,Back,Main_Speed-Deviation);
//		}
//		else
//		{
//			 Single_Wheel_Control(A1,Back,Main_Speed);
//			 Single_Wheel_Control(B1,Back,Main_Speed);
//			 Single_Wheel_Control(B2,Back,Main_Speed+Deviation);
//			 Single_Wheel_Control(A2,Back,Main_Speed-Deviation);
//		}
//	}
//}



