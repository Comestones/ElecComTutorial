#ifndef __WORK_H
#define __WORK_H			//Prevent redefinition
	
#include "main.h"


#define Sampling_Num 512//采到的点数
#define FFT_Pointer  1024//采样的两倍
float find_shijiacha(uint16_t a[],uint16_t b[],int num);//find time
int xcorr(float* x1,float* x2);
#endif
