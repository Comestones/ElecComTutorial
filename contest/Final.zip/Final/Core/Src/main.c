/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "math.h"
#include "work.h"
#include "arm_math.h"
#include "arm_const_structs.h"
#include "stdlib.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define RXBUFFERSIZE  256     //�???大接收字节数
#define ADCBBUFFERSIZE 4096
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

//定义全局变量

/**********************************************************  串口控制变量BEGIN *****/
char RxBuffer[RXBUFFERSIZE];   //接收数据
uint8_t aRxBuffer;			//接收中断缓冲
uint8_t Uart1_Rx_Cnt = 0;		//接收缓冲计数

int FLAG_A=0,FLAG_B=0,FLAG_C;
/**********************************************************  串口控制变量END *******/
/**********************************************************  adc变量BEGIN *****/
uint16_t adc_buffer1[ADCBBUFFERSIZE]={0};
uint16_t adc_buffer2[ADCBBUFFERSIZE]={0};
uint16_t adc_buffer3[ADCBBUFFERSIZE]={0};
uint16_t adc_buffer1_2[ADCBBUFFERSIZE]={0};
uint16_t adc_buffer2_2[ADCBBUFFERSIZE]={0};
uint16_t adc_buffer3_2[ADCBBUFFERSIZE]={0};

float fft_intput[4096*2]={0};
float fft_output[4096]={0};
float fft_max_v=0;
int max_num;
float ang1,ang2,ang3;
float jiaoducha1_ave,jiaoducha2_ave;
float jiaoducha1[20],jiaoducha2[20];
float ang_tem;




int flag_adcactive=0,flag_adcnormal=0;
int flagB_ready_buf1=0,flagB_ready_buf2=0;
int flagc_ready=0;
int adc_mod=0;//mod==0表示normal模式，在寻找峰�?�，mod==1表示active模式
/**********************************************************  adc变量END *****/

/*∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧  流程控制变量BEGIN ∧∧∧∧*/
//int adc_active_duoshao = 512;
int adc_b_real_duosaho = 4096;
int adc_active_panduan=1850;

/*∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨  流程控制变量END ∨∨∨∨*/

/*∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧  读取信号参数变量BEGIN ∧∧∧∧*/
float vpp_adc1,vpp_adc2,vpp_adc3;
float t31,t21;
/*∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨  读取信号参数变量END ∨∨∨∨*/

/*∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧  自定义函数变量BEGIN ∧∧∧∧*/





int adc_buffer_mode=1;//mode �?1，�?�择buffer，mode�?0，�?�择buffer_2

/*∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨  自定义函数变量END ∨∨∨∨*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/*∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧∧  自定义函数BEGIN ∧∧∧∧*/


void work_set_fangda_1()
{
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,1);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,1);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,1);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,1);
    
    
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_0,1);
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_4,1);
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_6,1);
    
    
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,1);
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,1);
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,1);
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,1);
}

void work_set_fangda_50()//1k
{
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,0);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,0);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,0);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,0);
    
    
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_0,0);
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_4,0);
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_6,0);
    
    
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,0);
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,0);
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2,0);
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,0);
}




void work_change_adc_buffer(int num)//num �?1，�?�择buffer，num�?0，�?�择buffer_2
{
    HAL_ADC_Stop_DMA(&hadc1);
	HAL_ADC_Stop_DMA(&hadc2);
	HAL_ADC_Stop_DMA(&hadc3);
    if(num)
    {
        HAL_ADC_Start_DMA(&hadc1,(uint32_t *)&adc_buffer2,adc_b_real_duosaho);
        HAL_ADC_Start_DMA(&hadc2,(uint32_t *)&adc_buffer3,adc_b_real_duosaho);
        HAL_ADC_Start_DMA(&hadc3,(uint32_t *)&adc_buffer1,adc_b_real_duosaho); 
    }
    else 
    {
        HAL_ADC_Start_DMA(&hadc1,(uint32_t *)&adc_buffer2_2,adc_b_real_duosaho);
        HAL_ADC_Start_DMA(&hadc2,(uint32_t *)&adc_buffer3_2,adc_b_real_duosaho);
        HAL_ADC_Start_DMA(&hadc3,(uint32_t *)&adc_buffer1_2,adc_b_real_duosaho); 
    }

}

void work_change_adc_realtime(void)//开启adc转换，在buffer中，4096个点
{
    HAL_ADC_Stop_DMA(&hadc1);
	HAL_ADC_Stop_DMA(&hadc2);
	HAL_ADC_Stop_DMA(&hadc3);
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)&adc_buffer2,adc_b_real_duosaho);
	HAL_ADC_Start_DMA(&hadc2,(uint32_t *)&adc_buffer3,adc_b_real_duosaho);
	HAL_ADC_Start_DMA(&hadc3,(uint32_t *)&adc_buffer1,adc_b_real_duosaho); 
}


int find_peek2peek_large(uint16_t buffer[],int num)
{
    int i,max=0,min=4096;
	int maxn[10],minn[10];
    for(i=0;i<num;i++)
    {
        if(max<buffer[i])
        {
            max=buffer[i];
        }
        if(min>buffer[i])
        {
            min=buffer[i];
        }
    }
    return max-min;
}

float find_peek2peek(uint16_t arr[], int n)
{
  int i, j, temp, max_sum=0,min_sum=0;
  int maxp[30]={0},minp[30]={0};
  int max_duoshao=30,shen_duoshao=2;
  
 for (i=0; i<max_duoshao; i++)
  minp[i] = 4095;
  
  for (i = 0; i < n - 1; i++)
  {
    if(maxp[max_duoshao-1]<arr[i])//find max
    {
      maxp[max_duoshao-1]=arr[i];
    }
    for(j=max_duoshao-1;j>0;j--)
    {
      if(maxp[j]>maxp[j-1])
      {
        temp=maxp[j];
        maxp[j]=maxp[j-1];
        maxp[j-1]=temp;
      }
    }

    if(minp[max_duoshao-1]>arr[i])//find min
    {
      minp[max_duoshao-1]=arr[i];
    }
    for(j=max_duoshao-1;j>0;j--)
    {
      if(minp[j]<minp[j-1])
      {
        temp=minp[j];
        minp[j]=minp[j-1];
        minp[j-1]=temp;
      }
    }  
  }
  for(i=shen_duoshao;i<max_duoshao;i++)
  {
    max_sum+=maxp[i];
    min_sum+=minp[i];
  }
  return (max_sum-min_sum) * 3.3 * 1.0f / (max_duoshao-shen_duoshao) / 4096;
}
#pragma endregion

int shuzu[36][2]={  {23,-10},   {19,-4},    {18,-3},    {15,3},     {9,2},  	{10,10},
                    {12,-8},    {14,-5},    {10,-1},     {2,-3},     {4,4}, 	 	{1,8},
                    {4,-17},    {4,-6},     {3,-4},     {2,2},      {-4,3}, 	{-1,13},
                    {-7,-19},   {-6,-13},   {-3,-3},    {-3,2},     {-2,9}, 	{-3,16},
                    {-14,-20},  {-13,-14},  {-11,-4},   {-7,4},     {-4,14},   	{-7,17},
                    {-20,-20},  {-18,-13},  {-16,-6},   {-12,5},    {-6,12},    {-9,20}};

int work_dingwei(int x,int y)
{
    float juli=100;
    float minju=1000;
    int i,j,i_rem;
    for(i=0;i<36;i++)
    {
		juli=sqrt( (shuzu[i][0]-x)*(shuzu[i][0]-x) + (shuzu[i][1]-y)*(shuzu[i][1]-y) );
        if(juli < minju )
        {
            minju = juli;
            i_rem=i;
        }
    }
    return i_rem;

}

float shuzu2[36][2]={   {-9,-100},       {-7,-99.5},       {-4,-97},        {-4.8,-98.9},       {-6.53,-102.8},  	{-6.13,-103.8},
                        {-8.43,-99.57},  {-7.14,-101.45},  {-5.2,-102.6},   {-6.56,-101.4},     {-8.15,-103.2}, 	{-7.02,-109.7},
                        {-7.2,-100.33},  {-7.94,-103},     {-7.61,-107.6},  {-8.93,-104.53},    {-9.42,-99.51}, 	{-6.89,-103.53},
                        {-6.89,-97.4},   {-7.92,-98.08},   {-7.42,-104.6},  {-7.35,-107.2},     {-7.725,-103.2}, 	{-5.46,-97.15},
                        {-7.43,-92.23},  {-6.915,-93.31},  {-4.17,-98.09},  {-3.94,-104.5},     {-6.39,-108.72},   	{-5.91,-104.55},
                        {-7.55,-93.57},  {-6.79,-97.79},   {-3.71,-97.92},  {-4.07,-101.18},    {-8.06,-102.9},     {-8.5,-118.71}};//磁铁


int work_dingweitie(float ang1,float ang2)
{
	float juli=100;
    float minju=1000;
    int i,j,i_rem;
    for(i=0;i<36;i++)
    {
		juli=sqrt( (shuzu2[i][0]-ang1)*(shuzu2[i][0]-ang1) + (shuzu2[i][1]-ang2)*(shuzu2[i][1]-ang2) );
        if(juli < minju )
        {
            minju = juli;
            i_rem=i;
        }
    }
    return i_rem;
	
}



float work_angle_cha(float an1,float an2)
{
	if(an1-an2 < -180)
		return an1-an2+360;
	else if(an1-an2 >180)
		return an1-an2-360;
	else return an1-an2;
}

























/*∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨∨  自定义函数END ∨∨∨∨*/

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_ADC3_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer, 1);//初始化，串口1中断
  printf("hello");
  

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  //自定义main内变�?
  

    int i=0;
    int j=0;
    int adc_p1,adc_p2,adc_p3;//用于active模式存储初始输出adc序列的峰峰值，判断是否误判

    int adc_sum1,adc_sum2,adc_sum3=0;//存储adc采集数据中的求和
  //flag b
	float zhiliu1,zhiliu2,zhiliu3;//记录波形直流量
	int weizhi1,weizhi2,weizhi3;//记录认为信号到达的时刻

	int rem_i;
	int tem;
	int sum1,sum2,sum3;//记录求和，使用其越界时间作为信号到达时间
	int zuobiaox,zuobiaoy;//时间差坐标，用于计算后续和向量表的距离
	
	
	int flagc_cnt=0;
	
	//work_set_fangda_50();

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	if(FLAG_A)//输出定位区域
	{
		
	}

	if(FLAG_B)
	{
		if(flagB_ready_buf1)
		{
			flagB_ready_buf1=0;
			adc_p1=find_peek2peek_large(adc_buffer1,adc_b_real_duosaho);
			adc_p2=find_peek2peek_large(adc_buffer2,adc_b_real_duosaho);
			adc_p3=find_peek2peek_large(adc_buffer3,adc_b_real_duosaho);
			if(adc_p1 > 1000 || adc_p2 > 1000 || adc_p3 > 1000)
			{
				HAL_TIM_Base_Stop(&htim2);//发现有用信号，关闭adc转换，避免被覆盖，接下来处理信号
				 for(i=0;i<4096;i++)//输出信号波形
				 {
				 	//printf("%d,%d,%d,%d\r\n",i,adc_buffer1[i],adc_buffer2[i],adc_buffer3[i]);
				 }
				printf("-9999,-9999,-9999,-9999\r\n");
                zhiliu1=zhiliu2=zhiliu3=0;
                for ( i = 0; i < 10; i++)
                {
                    zhiliu1+=adc_buffer1[i]*1.0f/10;
                    zhiliu2+=adc_buffer2[i]*1.0f/10;
                    zhiliu3+=adc_buffer3[i]*1.0f/10;
                }

//参数一
                for ( i = 0; i < 4096; i++)
                {
                    if(adc_buffer1[i]>zhiliu1+100)break;
                }
                i-=100;
                if(i<0)i=0;
                tem=i+10;
                zhiliu1=0;
                for(;i<tem;i++)
                {
                    zhiliu1+=adc_buffer1[i]*1.0f/10;
                }
                
                for(;i<4096;i++)
                {
                    if(adc_buffer1[i]>zhiliu1+10)break;
                }
                sum1=0;
                for(;i<4096;i++)
                {
                    sum1+=fabs(adc_buffer1[i]-zhiliu1);
                    if(sum1>adc_p1/4)
                    break;
                }
                weizhi1=i;

//参数二
                for ( i = 0; i < 4096; i++)
                {
                    if(adc_buffer2[i]>zhiliu2+100)break;
                }
                i-=100;
                if(i<0)i=0;

                tem=i+10;
                zhiliu2=0;
                for(;i<tem;i++)
                {
                    zhiliu2+=adc_buffer2[i]*1.0f/10;
                }
                
                for(;i<4096;i++)
                {
                    if(adc_buffer2[i]>zhiliu2+10)break;
                }
                sum2=0;
                for(;i<4096;i++)
                {
                    sum2+=fabs(adc_buffer2[i]-zhiliu2);
                    if(sum2>adc_p2/4)
                    break;
                }
                weizhi2=i;

//参数三
                for ( i = 0; i < 4096; i++)
                {
                    if(adc_buffer3[i]>zhiliu3+100)break;
                }
                i-=100;
                if(i<0)i=0;
                tem=i+10;
                zhiliu3=0;
                for(;i<tem;i++)
                {
                    zhiliu3+=adc_buffer3[i]*1.0f/10;
                }
                
                for(;i<4096;i++)
                {
                    if(adc_buffer3[i]>zhiliu3+10)break;
                }
                sum3=0;
                for(;i<4096;i++)
                {
                    sum3+=fabs(adc_buffer3[i]-zhiliu3);
                    if(sum3>adc_p3/4)
                    break;
                }
                weizhi3=i;				

                 printf(" xxx___ _%d\r\n",zuobiaox = weizhi3-weizhi2);
                 printf(" yyy___ _%d\r\n",zuobiaoy =  weizhi3-weizhi1);
                 printf("**********      %d     **********\r\n",work_dingwei(zuobiaox,zuobiaoy));
				work_change_adc_realtime();//接着采样
				adc_buffer_mode=1;
				HAL_TIM_Base_Start(&htim2);
			}
		}
        if(flagB_ready_buf2)
		{
			flagB_ready_buf2=0;
			adc_p1=find_peek2peek_large(adc_buffer1_2,adc_b_real_duosaho);
			adc_p2=find_peek2peek_large(adc_buffer2_2,adc_b_real_duosaho);
			adc_p3=find_peek2peek_large(adc_buffer3_2,adc_b_real_duosaho);
			if(adc_p1 > 1000 || adc_p2 > 1000 || adc_p3 > 1000)
			{
				HAL_TIM_Base_Stop(&htim2);
				for(i=0;i<4096;i++)
				{
					//printf("%d,%d,%d,%d\r\n",i,adc_buffer1_2[i],adc_buffer2_2[i],adc_buffer3_2[i]);
				}
				
				printf("-9999,-9999,-9999,-9999\r\n");

                zhiliu1=zhiliu2=zhiliu3=0;//直流量计算
                for ( i = 0; i < 10; i++)
                {
                    zhiliu1+=adc_buffer1_2[i]/10;
                    zhiliu2+=adc_buffer2_2[i]/10;
                    zhiliu3+=adc_buffer3_2[i]/10;
                }



//参数一
                for ( i = 0; i < 4096; i++)
                {
                    if(adc_buffer1_2[i]>zhiliu1+100)break;
                }
                i-=100;
                if(i<0)i=0;

                tem=i+10;
                zhiliu1=0;
                for(;i<tem;i++)
                {
                    zhiliu1+=adc_buffer1_2[i]*1.0f/10;
                }
                
                for(;i<4096;i++)
                {
                    if(adc_buffer1_2[i]>zhiliu1+10)break;
                }
                sum1=0;
                for(;i<4096;i++)
                {
                    sum1+=fabs(adc_buffer1_2[i]-zhiliu1);
                    if(sum1>adc_p1/4)
                    break;
                }
                weizhi1=i;



//参数二
                for ( i = 0; i < 4096; i++)
                {
                    if(adc_buffer2_2[i]>zhiliu2+100)break;
                }
                i-=100;
                if(i<0)i=0;

                tem=i+10;
                zhiliu2=0;
                for(;i<tem;i++)
                {
                    zhiliu2+=adc_buffer2_2[i]*1.0f/10;
                }
                
                for(;i<4096;i++)
                {
                    if(adc_buffer2_2[i]>zhiliu2+10)break;
                }
                sum2=0;
                for(;i<4096;i++)
                {
                    sum2+=fabs(adc_buffer2_2[i]-zhiliu2);
                    if(sum2>adc_p2/4)
                    break;
                }
                weizhi2=i;


//参数三
                for ( i = 0; i < 4096; i++)
                {
                    if(adc_buffer3_2[i]>zhiliu3+100)break;
                }
                i-=100;
                if(i<0)i=0;
                tem=i+10;
                zhiliu3=0;
                for(;i<tem;i++)
                {
                    zhiliu3+=adc_buffer3_2[i]*1.0f/10;
                }
                
                for(;i<4096;i++)
                {
                    if(adc_buffer3_2[i]>zhiliu3+10)break;
                }
                sum3=0;
                for(;i<4096;i++)
                {
                    sum3+=fabs(adc_buffer3_2[i]-zhiliu3);
                    if(sum3>adc_p3/4)
                    break;
                }
                weizhi3=i;




                 printf(" xxx___ _%d\r\n",zuobiaox = weizhi3-weizhi2);
                 printf(" yyy___ _%d\r\n",zuobiaoy =  weizhi3-weizhi1);
                 printf(" zzz___ _%d\r\n",weizhi2-weizhi1);
                 printf("**********      %d     **********\r\n",work_dingwei(zuobiaox,zuobiaoy));
//                printf(" shang___ _%d\r\n",weizhi1);
//                printf(" you___   _%d\r\n",weizhi2);
//                printf(" zuo___   _%d\r\n",weizhi3);


				work_change_adc_realtime();
				adc_buffer_mode=1;
				
				
				HAL_TIM_Base_Start(&htim2);
			}
		}
	}
    if(FLAG_C)
    {
        if(flagc_ready)
        {
            flagc_ready=0;
			flagc_cnt++;
            for(i=0;i<4096;i++)
            {
               // printf("%d,%d,%d,%d\r\n",i,adc_buffer1[i],adc_buffer2[i],adc_buffer3[i]);
            }
			
			for (i = 0; i < 4096; i++)
			{
				fft_intput[i * 2] = adc_buffer1[i] * 2.92*1.0f / 4096;//
				fft_intput[i * 2 + 1] = 0;//
			}
			printf("begin fft");
			arm_cfft_f32(&arm_cfft_sR_f32_len4096, fft_intput, 0, 1);//�?0，进行fft正变�?
			arm_cmplx_mag_f32(fft_intput, fft_output, 4096);

			fft_max_v=0;
			for(i=1;i<2048;i++)
			{
				if(fft_output[i]>fft_max_v)
				{
					fft_max_v=fft_output[i];
					max_num=i;
				}
			}
			printf("f_______  %.4f\r\n",max_num*50000*1.0f/4096);
			ang1=atan2(fft_intput[max_num*2+1], fft_intput[max_num*2]) * 180 / 3.1415926;
			printf(" ang______%.4f\r\n",ang1);
			
			
			
			
			
			
			
			
			
			
			for (i = 0; i < 4096; i++)
			{
				fft_intput[i * 2] = adc_buffer2[i] * 2.92*1.0f / 4096;//
				fft_intput[i * 2 + 1] = 0;//
			}
			printf("begin fft");
			arm_cfft_f32(&arm_cfft_sR_f32_len4096, fft_intput, 0, 1);//�?0，进行fft正变�?
			arm_cmplx_mag_f32(fft_intput, fft_output, 4096);

			fft_max_v=0;
			for(i=1;i<2048;i++)
			{
				if(fft_output[i]>fft_max_v)
				{
					fft_max_v=fft_output[i];
					max_num=i;
				}
			}
			printf("f_______  %.4f\r\n",max_num*50000*1.0f/4096);
			ang2=atan2(fft_intput[max_num*2+1], fft_intput[max_num*2]) * 180 / 3.1415926;
			printf(" ang______%.4f\r\n",ang2);
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			for (i = 0; i < 4096; i++)
			{
				fft_intput[i * 2] = adc_buffer3[i] * 2.92*1.0f / 4096;//
				fft_intput[i * 2 + 1] = 0;//
			}
			printf("begin fft");
			arm_cfft_f32(&arm_cfft_sR_f32_len4096, fft_intput, 0, 1);//�?0，进行fft正变�?
			arm_cmplx_mag_f32(fft_intput, fft_output, 4096);

			fft_max_v=0;
			for(i=1;i<2048;i++)
			{
				if(fft_output[i]>fft_max_v)
				{
					fft_max_v=fft_output[i];
					max_num=i;
				}
			}
			printf("f_______  %.4f\r\n",max_num*50000*1.0f/4096);
			ang3=atan2(fft_intput[max_num*2+1], fft_intput[max_num*2]) * 180 / 3.1415926;
			printf(" ang______%.4f\r\n",ang3);
			
			
			
			
			
			printf("cha--------    %.4f\r\n",work_angle_cha(ang1,ang2));
			printf("cha--------    %.4f\r\n",work_angle_cha(ang1,ang3));
			
			jiaoducha1[flagc_cnt-1]=work_angle_cha(ang1,ang2);
			jiaoducha2[flagc_cnt-1]=work_angle_cha(ang1,ang3);
			
			
			
			
			
			if(flagc_cnt>=20)
			{
				FLAG_C=0;//关闭flagc，直到下次测量命令到来
				flagc_cnt=0;
				for(i=0;i<20;i++)
				{
					for(j=0;j<20;j++)
					{
						if(jiaoducha1[i]>jiaoducha1[j])
						{
							ang_tem=jiaoducha1[i];
							jiaoducha1[i]=jiaoducha1[j];
							jiaoducha1[j]=ang_tem;
						}
					}
				}
				
				for(i=0;i<20;i++)
				{
					for(j=0;j<20;j++)
					{
						if(jiaoducha2[i]>jiaoducha2[j])
						{
							ang_tem=jiaoducha2[i];
							jiaoducha2[i]=jiaoducha2[j];
							jiaoducha2[j]=ang_tem;
						}
					}
				}
				jiaoducha1_ave=jiaoducha2_ave=0;
				for(i=4;i<16;i++)
				{
					jiaoducha1_ave+=jiaoducha1[i]*1.0f/12;
					jiaoducha2_ave+=jiaoducha2[i]*1.0f/12;
				}
				printf("\r\n");
				printf("jiaoducha1     %.4f\r\n",jiaoducha1_ave);
				printf("jiaoducha2     %.4f\r\n",jiaoducha2_ave);
				printf("**********     %d\r\n",work_dingweitie(jiaoducha1_ave,jiaoducha2_ave));
				
				
				
				
				
				
			}
			
            HAL_TIM_Base_Start(&htim2);
           
        }
    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	if(hadc==&hadc1)
	{
        HAL_TIM_Base_Stop(&htim2);
		
        if(FLAG_A)
        {
			//HAL_TIM_Base_Stop(&htim2);
            if(adc_mod)//active mod
            {
                
                flag_adcactive=1;
            }
            else
            {
                flag_adcnormal=1;
            }
        }
        else if(FLAG_B)
        {
            flagB_ready_buf1=adc_buffer_mode;
            flagB_ready_buf2=!adc_buffer_mode;
            work_change_adc_buffer(!adc_buffer_mode);
            adc_buffer_mode=!adc_buffer_mode;
			HAL_TIM_Base_Start(&htim2);
        }
        else if(FLAG_C)
        {
            flagc_ready=1;
        }		
	}

}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* 避免因为没有使用参数huart而产生warning */
  UNUSED(huart);
  /* NOTE: This function Should not be modified, when the callback is needed,
           the HAL_UART_TxCpltCallback could be implemented in the user file
   */
 
	if(Uart1_Rx_Cnt >= 255)  //溢出判断
	{
		Uart1_Rx_Cnt = 0;
		memset(RxBuffer,0x00,sizeof(RxBuffer));
		HAL_UART_Transmit(&huart1, (uint8_t *)"OVER", 10,0xFFFF); 	
        
	}
	else
	{
		RxBuffer[Uart1_Rx_Cnt++] = aRxBuffer;   //接收数据转存
	
		if((RxBuffer[Uart1_Rx_Cnt-1] == 0x0A)&&(RxBuffer[Uart1_Rx_Cnt-2] == 0x0D)) //判断结束�???
		{
			if(RxBuffer[Uart1_Rx_Cnt-3]=='A')
			{ 
				HAL_GPIO_TogglePin(LED1_GPIO_Port,LED1_Pin);
                FLAG_A=1;
                FLAG_B=0;
                printf("Flag_A\r\n");
			}
            else if(RxBuffer[Uart1_Rx_Cnt-3]=='B')
			{ 
				HAL_GPIO_TogglePin(LED1_GPIO_Port,LED1_Pin);
                FLAG_A=0;
                FLAG_B=1;
                printf("Flag_B\r\n");
                work_set_fangda_1();
                work_change_adc_realtime();
                HAL_TIM_Base_Start(&htim2);
			}
			 else if(RxBuffer[Uart1_Rx_Cnt-3]=='C')
			{ 
				HAL_GPIO_TogglePin(LED1_GPIO_Port,LED1_Pin);
                FLAG_A=0;
                FLAG_B=0;
                FLAG_C=1;
                printf("Flag_C\r\n");
                work_set_fangda_50();
                work_change_adc_realtime();
                HAL_TIM_Base_Start(&htim2);
			}
			Uart1_Rx_Cnt = 0;
			memset(RxBuffer,0x00,sizeof(RxBuffer)); //清空数组
		}
	}
	
	HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer, 1);   //再开启接收中�???
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
